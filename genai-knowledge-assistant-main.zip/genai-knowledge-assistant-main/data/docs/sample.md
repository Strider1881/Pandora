# Sample Notes

This is a sample knowledge file. Add your own Markdown, PDF, or TXT files
under `data/docs/` and run `python ingest.py` to index them.
